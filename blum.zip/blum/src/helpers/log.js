import colors from "colors";

export class LogHelper {
  constructor(index, userId) {
    this.index = index;
    this.userId = userId;
    this.ip = "🖥️";
  }

  log(msg) {
    console.log(
      `[!] ${msg}`
    );
  }

  logError(msg) {
    console.log(
      `[×] ${colors.red(
        msg
      )}`
    );
  }

  logSuccess(msg) {
    console.log(
      `[✔] ${colors.green(msg)}`
    );
  }

  updateIp(ip) {
    this.ip = ip;
  }
}

const logHelper = new LogHelper();
export default logHelper;
