class TokenHelper {
  constructor() {}

  isExpired(token) {
    const [, payloadBase64] = token.split(".");
    const base64 = payloadBase64.replace(/-/g, "+").replace(/_/g, "/");

    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join("")
    );

    const { exp } = JSON.parse(jsonPayload);
    const currentTimestamp = Math.floor(Date.now() / 1000);

    return exp < currentTimestamp;
  }

  getFormattedExpirationTime(token) {
    const [, payloadBase64] = token.split(".");
    const base64 = payloadBase64.replace(/-/g, "+").replace(/_/g, "/");
    const { exp } = JSON.parse(atob(base64));

    const expirationDate = new Date(exp * 1000);
    return expirationDate.toLocaleString("id-ID", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      timeZoneName: "short",
    });
  }
}

const tokenHelper = new TokenHelper();
export default tokenHelper;
