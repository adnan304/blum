import colors from "colors";
import moment from "moment";

class DailyService {
  constructor() {}

  /**
   * Retrieves check-in data for the user
   * @param {Object} user - User object
   * @returns {Object|number} Check-in data or status code
   */
  async getDataCheckin(user) {
    try {
      const { data } = await user.http.get(0, "daily-reward?offset=-420");
      return data?.days[2] || null;
    } catch (error) {
      if (error.status === 404 && error.response.data.message === "Not Found") {
        return 1; // Already checked in
      }
      return -1; // Error occurred
    }
  }

  /**
   * Performs daily check-in for the user
   * @param {Object} user - User object
   */
  async checkin(user) {
    const dataCheckin = await this.getDataCheckin(user);
    const currentTime = moment().format("YYYY-MM-DD HH:mm:ss");

    if (dataCheckin === 1) {
      user.log.log(colors.magenta(`[${currentTime}] Already checked in today`));
    } else if (dataCheckin?.reward) {
      try {
        const { data } = await user.http.post(0, "daily-reward?offset=-420");
        if (data) {
          user.log.log(
            colors.cyan(`[${currentTime}] Check-in successful:`) +
            colors.green(`\n  ► Reward: ${dataCheckin.reward.passes} plays`) +
            colors.yellow(`\n  ► Points: ${dataCheckin.reward.points} ${user.currency}`)
          );
        } else {
          throw new Error(`Check-in failed: ${data.message}`);
        }
      } catch (error) {
        user.log.logError(colors.red(`[${currentTime}] Check-in failed: ${error.response?.data?.message}`));
        return null;
      }
    }
  }
}

const dailyService = new DailyService();
export default dailyService;
