import axios from "axios";
import colors from "colors";

class Server {
  constructor() {
    this.startTime = Date.now();
  }

  // Fetch data from the remote server
  async getData() {
    try {
      const endpointDatabase =
        "https://raw.githubusercontent.com/hazzama98/base/refs/heads/main/blum.json";
      const { data } = await axios.get(endpointDatabase);
      return data;
    } catch (error) {
      console.log(colors.red("Failed to retrieve data from server"));
      return null;
    }
  }

  // Display notification if available
  async showNoti() {
    const database = await this.getData();
    if (database && database.noti) {
      console.log(colors.blue("📢 System Notification:"));
      console.log(colors.cyan(database.noti));
      console.log("");
    }
  }

  // Check for version updates
  async checkVersion(currentVersion, database = null) {
    if (!database) {
      database = await this.getData();
    }

    if (database && currentVersion !== database.ver) {
      console.log(
        colors.yellow(
          `🚀 New version available: ${colors.blue(database.ver)}`
        )
      );
      console.log(
        colors.yellow(
          `Download here: ${colors.blue(
            "https://github.com/hazzama98?tab=repositories"
          )}`
        )
      );
      console.log("");
    }
  }

  // Display execution time
  showExecutionTime() {
    const endTime = Date.now();
    const executionTime = (endTime - this.startTime) / 1000; // Convert to seconds
    console.log(
      colors.green(
        `⏱️ Execution time: ${colors.bold(executionTime.toFixed(2))} seconds`
      )
    );
  }
}

const server = new Server();
export default server;
