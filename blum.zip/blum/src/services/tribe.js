import colors from "colors";
import delayHelper from "../helpers/delay.js";

class TribeService {
  constructor() {}
  async getInfo(user) {
    try {
      const { data } = await user.http.get(2, "tribe/my");
      if (data) {
        return data;
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      if (error.response?.data?.message === "NOT_FOUND") {
        return false;
      } else {
        return null;
      }
    }
  }

  async handleTribe(user) {
    try {
      const tribeInfo = await this.getInfo(user);
      if (tribeInfo) {
        user.log.log(``);
        // Tambahkan logika penanganan suku di sini
      } else {
        user.log.log('Pengguna tidak memiliki tribe');
      }
    } catch (error) {
      user.log.logError(`Gagal menangani tribe: ${error.message}`);
    }
  }
}

const tribeService = new TribeService();
export default tribeService;
