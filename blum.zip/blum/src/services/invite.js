import colors from "colors";
import moment from "moment";

class InviteClass {
  constructor() {}

  async getBalanceInvite(user) {
    const startTime = process.hrtime();
    try {
      const { data } = await user.http.get(3, "friends/balance");
      if (data) {
        this.logExecutionTime("getBalanceInvite", startTime);
        return data;
      } else {
        throw new Error("Failed to retrieve invite balance information");
      }
    } catch (error) {
      user.log.logError(`Error retrieving invite balance: ${error.message}`);
      this.logExecutionTime("getBalanceInvite", startTime);
      return null;
    }
  }

  async claimInvite(user) {
    const startTime = process.hrtime();
    try {
      const { data } = await user.http.post(3, "friends/claim", {});
      if (data) {
        user.log.log(
          `${colors.green("✓")} Referral points claimed successfully. Received: ${colors.cyan(data?.claimBalance)} ${user.currency}`
        );
        this.logExecutionTime("claimInvite", startTime);
        return true;
      } else {
        throw new Error("Failed to claim referral points");
      }
    } catch (error) {
      user.log.logError(`Error claiming referral points: ${error.message}`);
      this.logExecutionTime("claimInvite", startTime);
      return false;
    }
  }

  async handleInvite(user) {
    const startTime = process.hrtime();
    const balance = await this.getBalanceInvite(user);
    if (balance && balance.amountForClaim > 0 && balance.canClaim) {
      await this.claimInvite(user);
    }
    this.logExecutionTime("handleInvite", startTime);
  }

  logExecutionTime(methodName, startTime) {
    const endTime = process.hrtime(startTime);
    const executionTime = (endTime[0] * 1000 + endTime[1] / 1e6).toFixed(2);
    console.log(
      `${colors.yellow("⚡")} ${colors.blue(methodName)} executed in ${colors.magenta(executionTime)} ms at ${colors.gray(moment().format("HH:mm:ss"))}`
    );
  }
}

const inviteClass = new InviteClass();
export default inviteClass;
